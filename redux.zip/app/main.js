var React = require('react');
var react_dom = require('react-dom');
var AppComponent = require('./components/productBox.jsx');
react_dom.render(<AppComponent />, document.getElementById('content'));